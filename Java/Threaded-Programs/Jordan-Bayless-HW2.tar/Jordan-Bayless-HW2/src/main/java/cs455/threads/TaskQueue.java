package cs455.threads;

import java.util.Stack;

public class TaskQueue extends Thread{
    Stack<Task> taskqueue;

    TaskQueue(){
        this.taskqueue = new Stack<>();
    }
}
