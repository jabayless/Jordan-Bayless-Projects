package cs455.threads;

public class Task extends Thread{
    private final Matrix row;
    private final Matrix column;
    private final Matrix resultant;
    private final int indexI;
    private final int indexJ;
    private final JobStatus job;

    Task(Matrix row, Matrix column, Matrix result, int indexI, int indexJ, JobStatus job) {
        this.row = row;
        this.column = column;
        this.resultant = result;
        this.indexI = indexI;
        this.indexJ = indexJ;
        this.job = job;
    }

    public boolean dotProduct() {
        int[][] a = this.row.getMatrix();
        int[][] b = this.column.getMatrix();
        int[][] c = this.resultant.getMatrix();
        c[this.indexI][this.indexJ] = 0;
        for (int k = 0; k < row.getMatrix().length; k++) {
            c[this.indexI][this.indexJ] += a[this.indexI][k] * b[k][this.indexJ];
        }
        this.resultant.updateMatrix(c[this.indexI][this.indexJ], this.indexI, this.indexJ);
        this.job.incrementNumberOfTasksCompleted();
        if(((this.indexI == 0) && (this.indexJ == 0)) ||
                ((this.indexI == this.column.getMatrix().length -1) && (this.indexJ == this.column.getMatrix().length -1))){
            this.job.increment();
        }
        return true;
    }
}