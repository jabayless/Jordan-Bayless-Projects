package cs455.threads;

import java.util.Vector;

public class ThreadPool{
    public Vector<AThread> pool;
    public TaskQueue queue;
    public boolean done = false;
    public int numberOfThreads;

    ThreadPool(int numberOfThreads, TaskQueue queue) {
        this.pool = new Vector<>();
        this.numberOfThreads = numberOfThreads;
        this.queue = queue;
        for(int i = 0 ; i < numberOfThreads; i++){
            this.pool.add(new AThread(this));
        }
    }

    public void startThreads() {
        for(int i = 0; i < this.numberOfThreads; i++){
            try {
                this.pool.get(i).start();
            }catch (java.lang.NullPointerException e){
                e.printStackTrace();
            }
        }
    }

    public synchronized Task getNewTask() {
        if(!this.queue.taskqueue.isEmpty()){
            return this.queue.taskqueue.pop();
        }
        else{
            return null;
        }
    }
}

