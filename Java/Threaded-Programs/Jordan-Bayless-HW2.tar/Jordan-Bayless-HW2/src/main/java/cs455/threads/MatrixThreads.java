package cs455.threads;

import java.text.DecimalFormat;
import java.util.Random;
public class MatrixThreads extends Thread{
    final double THOUSAND = 1000.0;
    final int BILLION = 1000000000;
    //intance variables
    private Matrix matrixA;
    private Matrix matrixB;
    private Matrix matrixC;
    private Matrix matrixD;
    private Matrix matrixX;
    private Matrix matrixY;
    private Matrix matrixZ;
    private final int threadPoolSize;
    private final int matrixDimension;
    private final int seed;
    private final TaskQueue taskQueue;
    private final ThreadPool pool;
    private final Random random;
    private final JobStatus job;

    //MASSIVE constructor
    MatrixThreads(int threadPoolSize, int matrixDimension, int seed){
        this.threadPoolSize = threadPoolSize;
        this.matrixDimension = matrixDimension;
        this.seed = seed;
        this.random = new Random(this.seed);
        this.taskQueue = new TaskQueue();
        this.pool = new ThreadPool(this.threadPoolSize, taskQueue);
        this.matrixA = new Matrix(new int[this.matrixDimension][this.matrixDimension]);
        this.matrixB = new Matrix(new int[this.matrixDimension][this.matrixDimension]);
        this.matrixC = new Matrix(new int[this.matrixDimension][this.matrixDimension]);
        this.matrixD = new Matrix(new int[this.matrixDimension][this.matrixDimension]);
        this.matrixX = new Matrix(new int[this.matrixDimension][this.matrixDimension]);
        this.matrixY = new Matrix(new int[this.matrixDimension][this.matrixDimension]);
        this.matrixZ = new Matrix(new int[this.matrixDimension][this.matrixDimension]);
        this.matrixA = this.fillMatrix(this.matrixA);
        this.matrixB = this.fillMatrix(this.matrixB);
        this.matrixC = this.fillMatrix(this.matrixC);
        this.matrixD = this.fillMatrix(this.matrixD);
        this.matrixX = this.fillWithZero(this.matrixX);
        this.matrixY = this.fillWithZero(this.matrixY);
        this.matrixZ = this.fillWithZero(this.matrixZ);
        this.sumMatrices();
        this.pool.startThreads();
        this.job = new JobStatus(this.matrixDimension);
    }

    //main
    public static void main(String[] args){
        //check and validate the arguments
        if(validateArgs(args)){

            //create a new MatrixThreads object
            MatrixThreads newProject = new MatrixThreads(Integer.parseInt(args[0]),
                    Integer.parseInt(args[1]), Integer.parseInt(args[2]) );
            newProject.initialPrint(newProject);

            //compute matrixX and time it
            final double startTime = System.currentTimeMillis();
            newProject.computeMatrix(newProject.getMatrixA(),
                    newProject.getMatrixB(), newProject.getMatrixX());
            newProject.checkFinished(2,1);
            double endTimeMatrixX = ((System.currentTimeMillis() - startTime) / newProject.THOUSAND);

            //compute matrixY and time it
                    newProject.computeMatrix(newProject.getMatrixC(),
                    newProject.getMatrixD(), newProject.getMatrixY());
            newProject.checkFinished(4,2);
            double endTimeMatrixY = (((System.currentTimeMillis() - startTime) / newProject.THOUSAND) - endTimeMatrixX);

            //compute matrixZ and time it
            newProject.computeMatrix(newProject.getMatrixX(),
                    newProject.getMatrixY(), newProject.getMatrixZ());
            newProject.checkFinished(6,3);
            double endTimeMatrixZ = (((System.currentTimeMillis() - startTime) / newProject.THOUSAND) - endTimeMatrixY);
            //sum the matrices
            while(!newProject.job.getJobsDone()){}
            while(newProject.job.getNumberOfTasksCompleted() !=
                    (newProject.matrixDimension * newProject.matrixDimension * 3)){
                System.out.println(newProject.job.getNumberCompleted());
            }
            if(newProject.job.getNumberOfTasksCompleted() ==
                    (newProject.matrixDimension * newProject.matrixDimension * 3)){
                newProject.sumXYZ();
                //newProject.printMatrix(newProject.matrixX, "X");
                //print results
                newProject.finalPrint(endTimeMatrixX, endTimeMatrixY, endTimeMatrixZ);
            }

//            newProject.checkValues();
            //kill the threads
            newProject.killThreads();
            System.exit(0);
        }
        //if args weren't valid
        else{
            System.out.println("Failed...");
            System.exit(1);
        }
    }

    public void checkFinished(int numTasksComplete, int numberMatrixsComplete){
        while((this.job.getNumberCompleted() < numTasksComplete) && (!this.taskQueue.taskqueue.isEmpty()) ||
                (this.job.getNumberOfTasksCompleted() <
                        (this.matrixDimension * this.matrixDimension * numberMatrixsComplete))){}
    }

    public void computeMatrix(Matrix input1, Matrix input2, Matrix resultant){
        int previousNumberFinishedMatrices = this.job.getNumberCompleted();
        this.addTasks(input1, input2, resultant);
        while((this.job.getNumberCompleted() != previousNumberFinishedMatrices + 2) &&
                (!this.taskQueue.taskqueue.isEmpty())){}
    }

    public void initialPrint(MatrixThreads newProject){
        System.out.println("Dimensionality of the square matrices is: " + newProject.matrixDimension);
        System.out.println("The thread pool size has been initialized to: " + newProject.threadPoolSize);
        System.out.println("\nSum of the elements in input matrix A = " + newProject.matrixA.getSum());
        System.out.println("Sum of the elements in input matrix B = " + newProject.matrixB.getSum());
        System.out.println("Sum of the elements in input matrix C = " + newProject.matrixC.getSum());
        System.out.println("Sum of the elements in input matrix D = " + newProject.matrixD.getSum());
    }

    public void finalPrint(double endTimeMatrixX, double endTimeMatrixY, double endTimeMatrixZ){
        DecimalFormat df = new DecimalFormat("##.###");
        System.out.println("\nCalculation of matrix X (product of A and B) complete – sum of the elements in X is: " +
                this.matrixX.getSum() + "\nTime to compute matrix X: " + df.format(endTimeMatrixX) + "s");
        System.out.println("\nCalculation of matrix Y (product of C and D) complete – sum of the elements in Y is: " +
                this.matrixY.getSum() + "\nTime to compute matrix Y: " + df.format(endTimeMatrixY) + "s");
        System.out.println("\nCalculation of matrix Z (product of X and Y) complete – sum of the elements in Z is: " +
                this.matrixZ.getSum() + "\nTime to compute matrix Z: " + df.format(endTimeMatrixZ) + "s");

        double elapsedTime = endTimeMatrixX + endTimeMatrixY + endTimeMatrixZ;
        System.out.println("\nCumulative time to compute matrices X, Y, " +
                "and Z using a thread pool of size = " + this.threadPoolSize + " is : " + df.format(elapsedTime) + "s");
    }

    public void printMatrix(Matrix matrix, String matrixName){
        System.out.println("\n-----------------------------------------------------------------------------");
        System.out.println("Matrix " + matrixName + ":");
        for(int i = 0 ; i < this.matrixDimension; i++){
            System.out.printf("\n");
            for(int j = 0; j < this.matrixDimension; j++){
                System.out.printf("%d%s", matrix.getMatrix()[i][j], " ");
            }
        }
        System.out.printf("\n");
    }

    //check the arguments
    public static boolean validateArgs(String[] args){
        if (args.length != 3){
            System.out.println("Incorrect number of args supplied: " + args.length +
                    ". System exiting...");
            return false;
        }
        try {
            if ((Integer.parseInt(args[0]) < 1) || (Integer.parseInt(args[0]) > 15)) {
                System.out.println("Thread pool size of " + args[0] + " is outside the range of" +
                        " between 1 and 15. System exiting...");
                return false;
            }
        } catch (java.lang.NumberFormatException e){
            System.out.println("A number between 1 and 15 should be supplied as first argument to " +
                    "program. You typed: " + args[0] + ". System exiting...");
            return false;
        }
        try {
            if ((Integer.parseInt(args[1]) < 300) || (Integer.parseInt(args[1]) > 3000)) {
                System.out.println("Matrix dimension of " + args[1] + " is outside the range of" +
                        " between 300 and 3000. System exiting...");
                return false;
            }
        } catch (java.lang.NumberFormatException e){
            System.out.println("A number between 300 and 3000 should be supplied the as second argument to " +
                    "program. You typed: " + args[1] + ". System exiting...");
            return false;
        }
        try {
            long seed = Integer.parseInt(args[2]);
        } catch (java.lang.NumberFormatException e){
            System.out.println("An integer should be supplied as the third argument to " +
                    "program. Yout typed: " + args[2] + ". System exiting...");
            return false;
        }
        return true;
    }
    //getters
    public int getRandomNumber(){
        return this.random.nextInt();
    }

    public Matrix getMatrixA() {
        return matrixA;
    }

    public Matrix getMatrixB() {
        return matrixB;
    }

    public Matrix getMatrixC() {
        return matrixC;
    }

    public Matrix getMatrixD() {
        return matrixD;
    }

    public Matrix getMatrixX() {
        return matrixX;
    }

    public Matrix getMatrixY() {
        return matrixY;
    }

    public Matrix getMatrixZ() {
        return matrixZ;
    }

    public Matrix fillMatrix(Matrix matrix) {
        //fill the matrix
        for(int i = 0 ; i < this.matrixDimension; i++){
            for(int j = 0; j < this.matrixDimension; j++){
                matrix.updateMatrix(this.getRandomNumber(), i, j);
            }
        }
        return matrix;
    }

    public Matrix fillWithZero(Matrix matrix){
        //fill the matrix
        for(int i = 0 ; i < this.matrixDimension; i++){
            for(int j = 0; j < this.matrixDimension; j++){
                matrix.updateMatrix(0, i, j);
            }
        }
        return matrix;
    }

    //terminates all the threads
    public void killThreads(){
        this.pool.done = true;
        for(int i = 0; i < this.threadPoolSize; i++){
            try {
                this.pool.pool.get(i).setIsDone(false);
            }catch (NullPointerException e){ }
        }
    }

    public void addTasks(Matrix matrix1, Matrix matrix2, Matrix resultMatrix){
        int i, j;
        int N = this.matrixDimension;
        for (i = 0; i < N; i++) {
            for (j = 0; j < N; j++) {
                this.taskQueue.taskqueue.push(new Task(matrix1, matrix2, resultMatrix, i, j, this.job));
            }
        }
    }

    //add tasks to sum matrix
    public void sumMatrices(){
        this.sumMatrix(this.matrixA);
        this.sumMatrix(this.matrixB);
        this.sumMatrix(this.matrixC);
        this.sumMatrix(this.matrixD);
    }

    public void sumXYZ(){
        if(!this.job.getJobsDone()){
            System.out.println("FAILED!!!");
        }
        for(int i = 0 ; i < this.matrixDimension; i++) {
            for (int j = 0; j < this.matrixDimension; j++) {
                if (this.matrixZ.getMatrix()[i][j] == 0) {
                    System.out.println("failed...");
                }
            }
        }
        this.sumMatrix(this.matrixX);
        this.sumMatrix(this.matrixY);
        this.sumMatrix(this.matrixZ);
    }

    public void sumMatrix(Matrix summation){
        for(int i = 0 ; i < summation.getMatrix().length; i++){
            for(int j = 0; j < summation.getMatrix().length; j++){
                summation.updateSum(summation.getMatrix()[i][j]);
            }
        }
    }
}
