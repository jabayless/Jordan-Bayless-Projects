package cs455.threads;

public class JobStatus {
    private int numberCompleted = 0;
    private boolean jobsDone = false;
    private final int numberTasksToComplete;
    private int numberOfTasksCompleted = 0;

    JobStatus(int matrixDimension){
        this.numberTasksToComplete = (matrixDimension * matrixDimension * 3);
    }

    public int getNumberCompleted(){ return this.numberCompleted;}

    public synchronized int getNumberOfTasksCompleted() { return this.numberOfTasksCompleted; }

    public boolean getJobsDone(){ return this.jobsDone; }

    public synchronized void incrementNumberOfTasksCompleted(){
        this.numberOfTasksCompleted++;
        this.checkJobDone();
    }

    public void increment(){
        this.numberCompleted++;
        this.checkJobDone();
    }

    private synchronized void checkJobDone(){
        if((this.numberCompleted == 6) && (this.numberOfTasksCompleted == this.numberTasksToComplete)){
            this.jobsDone = true;
        }
    }

}
