package cs455.threads;

public class Matrix extends Thread{
    private int[][] matrix;
    private int sum;

    Matrix(int[][] matrix){
        this.matrix = matrix;
        this.sum = 0;
    }

    public int getSum(){ return this.sum;}

    public int[][] getMatrix(){ return this.matrix;}

    public synchronized void updateMatrix(int result, int indexI, int indexJ){
        this.matrix[indexI][indexJ] = result;
    }

    public void updateSum(int sum){
        this.sum += sum;
    }
}
