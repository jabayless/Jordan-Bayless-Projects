package cs455.threads;

public class AThread extends Thread {
    private Task task;
    public ThreadPool pool;
    public boolean isWorking = false;
    public boolean isRunning;

    AThread(ThreadPool pool){
        this.isRunning = false;
        this.pool = pool;
        this.task = null;

    }

    public void setIsDone(boolean isdone){
        this.isRunning = isdone;
    }
    public void run() {
        this.isRunning = true;
        while (this.isRunning){
            if(this.task == null){
                this.task = this.pool.getNewTask();
                if(!(this.task == null)) {
                    this.isWorking = true;
                    if (this.task.dotProduct()) {
                        this.task = null;
                        this.isWorking = false;
                    }
                }
            }
        }
    }
}
