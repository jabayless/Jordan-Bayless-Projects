Jordan Bayless
CS455 HW2
README 
Mar 15, 2021

Example command on how to run program.
change directories in the gradle files to the build/classes/java/main/ folder.
once there, example command: java MatrixThreads 1 1000 31459

Classes:

-MatrixThreads Class:

*The MatrixThreads class is the most complex and has the most responsibilities, it primarily acts as a driver class
for the rest of the program. MatrixThreads contains both a main method to run all the other classes as well as 
instance variables. in main the sequence goes something like this. 1.) The command line arguments are parsed and checked
for validity and size constraints. 2.) The MatrixThread object is created which contains instance variables for all the 
other objects (all 7 matrices A-D are filled using Random number generator, X-Z are filled with 0s), the empty TaskQueue,
the ThreadPool object, and a jobStatus Object. Additionally the ThreadPool is initialized with the amount of thread objects
that the user specified. The threads are started only once. 3.) Matrices A-D are summed up and printed. 4.) Matrix A and B
and X are passed to a method (computeMatrix) which loops through the size of the matrix dimensions and creates a new task for
each element in the resultant matrix which need to be calculated using the matrix dot product. All these Task objects are placed
inside the task queue. 5.) Matrix C, D and Y are passed to the same function. After checking using the job object that Matrices 
X and Y have all their elements filled and that the task queue is empty, the final call to this method is made to compute Z.
The timings for all the matrices, and their summations are then printed to the screen. 6.) The threads are killed. 7.) The 
program terminates.

-Matrix Class

*A 2 dimensional array of integers. Intance methods include a synchronized updateMatrix method to change the value of a cell.
And a summation update method to update the matrix's sum.

-JobStatus class

*This class is passed to all Task objects which can increment the counter when they have completed calculating a dot product
for a cell. The jobstatus class also has a boolean called jobsDone which becomes true after all the matrices have been computed
letting MatrixThreads class know when to print off all the values.

:wq

-Task class

*This class represents a single cell calculation of the dot product of two matrices. It is run by the AThread objects. Once
the dot product of that cell is calculated, it updates 1 cell in the resultant matrix object that is passed to it in its 
constructor. The instance variables are Matrix1, Matrix2, ResultantMatrix, indexI, indexJ (to know which cell to compute).

-TaskQueue class

*This class stores all the Task objects created in MatrixThreads in a stack.

-ThreadPool class

*This class stores the Thread Objects, creates them once and passes a reference to itself as a parameter to the constructors
of the AThread objects it creates. It creates exactly as many AThreads as the user specifies as the first command line arg. 
It contains a special method called getTask which is synchronized, it returns a task object to the AThread object.

-AThread class

*This class is a custom thread that stays in its run method once created and will not leave it until a boolean it set to false
inside some other class. The constructor of this class is passed the ThreadPool object reference so it can access the ThreadPool
objects getTask method. This class has 3 variables isDone boolean, a Task object and a reference to the ThreadPool object. Once in
its run method, it will request a task from the ThreadPool object, get a task, compute the dot product, update the resultant matrix
then request a new Task until the TaskQueue is empty. Once isDone is set to false, the thread exits its run method and essentially dies.
 
