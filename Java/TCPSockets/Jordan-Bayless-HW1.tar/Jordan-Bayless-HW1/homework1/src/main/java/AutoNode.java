import java.util.Scanner;
import java.lang.*;
import java.io.*;
import java.net.*;
import java.io.IOException;
import java.util.ArrayList;

public class AutoNode extends Thread {
    private Node peer;
    private String hostIp;
    private int portToConnet;
    private Scanner input = new Scanner(System.in);
    private boolean begin = false;
    private ArrayList<String[]> Addresses = new ArrayList<String[]>();
    private String collatorIp;
    private int collatorPort;

    final static int upperInt = 32768;
    final static int lowerInt = -32767;

    //hw1 variables
    //number of messages sent
    private int sendTracker = 0;
    //number of messages received
    private int receiverTracker = 0;
    //totals
    private int summation = 0;
    private int sendSummation = 0;

    AutoNode() {    }

    public ArrayList<String[]> getAddresses(){ return this.Addresses;}

    //builds an autonode object and calls the method to start the server
    public static void main(String args[]) {
        /*
        1.) Program is turned on
        2.) post listening port and ip to text file
        3.) read from file until collator posts that all nodes have been turned
        4.) add the ports to the data structure but not including it's own port and ip
        5.) randomly connect to
        6.) Gracefully break the connections
         */
        AutoNode controller = new AutoNode();
        System.out.println("AutoNode online.\n");
        controller.peer = new Node();
        controller.peer.setAutoNode(true);
        controller.runServer(controller);
    }

    //allows you to connect to another node and listen to messages coming from it
    public void runClient(AutoNode controller) throws IOException, InterruptedException {
        this.getCollatorInfo();
        System.out.println("About to send 5000 messages to list of " +
                controller.getAddresses().size() + " nodes.\n This is the list of other nodes:");
        for(int i = 0; i < controller.getAddresses().size(); i++){
            System.out.println(controller.getAddresses().get(i)[0] + " " + controller.getAddresses().get(i)[1]);
        }
        for(int i = 0 ; i < 5000; i++) {
            //get randomNode to connect to
            int myNode = controller.peer.getRandomNumber(0, controller.getAddresses().size());
            controller.hostIp = controller.Addresses.get(myNode)[0];
            controller.portToConnet = Integer.parseInt(controller.Addresses.get(myNode)[1]);
            controller.peer.setConnectPort(controller.portToConnet);
            try {
                boolean successfulConnect = controller.peer.attemptConnection(InetAddress.getByName(controller.hostIp));
                if(successfulConnect){
                    controller.sendMessage();
                }
                else{
                    i--;
                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
            //client needs to write to server
        }
        System.out.println("Sent all messages.");
        Thread.sleep(20000);
        controller.receiverTracker = controller.peer.getNumMessagesReceived();
        controller.summation = controller.peer.getPartialSum();
        System.out.println("\nI have sent all my messages. Messages received: " + this.receiverTracker +
                ". Messages sent: " + this.sendTracker);

        //now send your report to the collator
        controller.hostIp = collatorIp;
        controller.portToConnet = collatorPort;
        controller.peer.setConnectPort(controller.portToConnet);
        try {
            controller.peer.attemptConnection(InetAddress.getByName(controller.hostIp));
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        controller.reportToCollator();
    }

    public void getCollatorInfo() throws IOException, InterruptedException {
        Thread.sleep(1000);
        String sCurrentLine;
        BufferedReader br = null;
        String lastLine = "";
        try {
            br = new BufferedReader(new FileReader("Addresses.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        while ((sCurrentLine = br.readLine()) != null) {
            lastLine = sCurrentLine;
        }
        // removing first character
        for(int i = 0; i < 18; i++){
            lastLine.substring(1);
        }
        String st = lastLine;
        String[] fullAddress = st.split(" ");
        fullAddress[2].replaceAll("[\\n ]", "");
        fullAddress[3].replaceAll("[\\n ]", "");
        String[] addressToAdd = new String[2];
        this.collatorIp = fullAddress[2];
        this.collatorPort = Integer.parseInt(fullAddress[3]);
    }

    /*
    starts the node object and makes it listen on its port and post its port and address to
    the text file shared between all node objects
    1.) Server needs to read from client node
     */
    public static void runServer(AutoNode controller) {
        InetAddress inetIp = controller.peer.getip();
        String ip = inetIp + "";
        String[] fullIp = ip.split("/");
        ip = fullIp[1];
        String str = ip + " " + controller.peer.getListeningPort() + "\n";
        System.out.println("My address is: " + str);
        String fileName = "Addresses.txt";
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.append(str);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Wait for all nodes to come online and collator to tell them to start doing their thing
        while (!controller.begin) {
            try {
                File file = new File("Addresses.txt");
                BufferedReader br = new BufferedReader(new FileReader(file));
                String st;
                try {
                    while ((st = br.readLine()) != null) {
                        if (st.contains("Collator")) {
                            controller.getAllNodes(controller);
                            controller.begin = true;
                            break;
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        controller.peer.setServerSocket();
        controller.start();
        controller.peer.start();
    }

    //allows the node to send messages to the other node
    //should allow client to send message to server
    public void sendMessage() {
        for(int i = 0; i < 5; i++){
            int message = this.peer.getRandomNumber(lowerInt, upperInt);
            this.sendSummation += message;
            this.peer.sendMessageToServer(message);
            this.sendTracker++;
        }
    }

    public void reportToCollator() throws InterruptedException {
        this.peer.sendMessageToServer(this.receiverTracker);
        this.peer.sendMessageToServer(this.sendTracker);
        this.peer.sendMessageToServer(this.summation);
        System.out.println("Send summation is " + this.sendSummation);
        this.peer.sendMessageToServer(this.sendSummation);
        System.out.println("Sent report to collator");
        Thread.sleep(5000);
        System.exit(0);
    }

    /*
    adds all the nodes' ip's and ports to a hashmap to use to pass messages
    retrieves them from a text file
     */
    public void getAllNodes(AutoNode controller) {
        try {
            File file = new File("Addresses.txt");
            BufferedReader br = new BufferedReader(new FileReader(file));
            String st;
            try {
                while ((st = br.readLine()) != null) {
                    if (st.contains("Collator")) {
                        break;
                    }
                    //remove its own port and ip from the list
                    else if ((st.contains(String.valueOf(controller.peer.getListeningPort())))) {
                        continue;
                    } else {
                        //add the port and ip's to the data structure but not its own
                        //split the string and strip it of new line
                        String[] fullAddress = st.split(" ");
                        fullAddress[1].replaceAll("[\\n ]", "");
                        fullAddress[0].replaceAll("[\\n ]", "");
                        String[] addressToAdd = new String[2];
                        addressToAdd[0] = fullAddress[0];
                        addressToAdd[1] = fullAddress[1];
                        Addresses.add(addressToAdd);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    //threaded method to have reader and sender messages as different threads

    public void run() {
        try {
            this.runClient(this);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}