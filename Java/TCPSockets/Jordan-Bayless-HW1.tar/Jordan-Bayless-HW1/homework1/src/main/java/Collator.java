import java.net.InetAddress;
import java.util.Scanner;
import java.io.*;
import java.io.IOException;
import java.util.Vector;

public class Collator extends Thread{
    private Node nexus;
    private int numberOfNodes;

    Collator(){
        nexus = new Node();
    }

    public int getNumberOfNodes(){
        return this.numberOfNodes;
    }

    public void setNumberOfNodes(int numberOfNodes){
        this.numberOfNodes = numberOfNodes;
    }

    public static void main(String args[]){
        String fileName = "Addresses.txt";
        Collator controller = new Collator();
        Node.clearPorts();
        controller.nexus.setAutoNode(false);
        Scanner input = new Scanner(System.in);
        System.out.println("Enter an integer 5-9 for number of nodes to deploy.");
        controller.setNumberOfNodes(input.nextInt());
        boolean correctNumberOfNodes = false;
        while(!correctNumberOfNodes) {
            if ((controller.getNumberOfNodes() < 5) || (controller.getNumberOfNodes() > 9)) {
                System.out.println("You requested " + controller.getNumberOfNodes() + " Nodes. Please enter an" +
                        "integer between 5 and 9.");
                controller.setNumberOfNodes((input.nextInt()));
            }
            else{
                correctNumberOfNodes = true;
            }
        }
        System.out.println("Waiting for all nodes to come online...");
        //clear the file
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(fileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        writer.close();
        writer.print("");
        //get all the ip's and ports into a file
        while(controller.getLines() != controller.getNumberOfNodes()){
            controller.getLines();
        }
        String str = "Collator " + controller.getNumberOfNodes() + "\n";
        try {
            BufferedWriter writerer = new BufferedWriter(new FileWriter(fileName, true));
            writerer.append(str);
            writerer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        controller.runServer(controller);
        //sleep for 2 seconds

        //post collator: ip and port number

        //start listening for the summations

        //once the number of summations received is equal to the number of nodes, display the info

        //call display info
    }

    public int getLines(){
        int lines = 0;
        try {
            try {
                BufferedReader reader = new BufferedReader(new FileReader("Addresses.txt"));
                while (reader.readLine() != null) lines++;
                reader.close();
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }
        } catch (IOException e){
            e.printStackTrace();
        }
        return lines;
    }

    public void runServer(Collator controller) {
        InetAddress inetIp = controller.nexus.getip();
        String ip = inetIp + "";
        String[] fullIp = ip.split("/");
        ip = fullIp[1];
        String str = "Collator address: " + ip + " " + controller.nexus.getListeningPort() + "\n";
        String fileName = "Addresses.txt";
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.append(str);
            writer.close();
        } catch (IOException e){
            e.printStackTrace();
        }
        //Wait for all nodes to come online then listen for their results
        controller.nexus.setServerSocket();
        controller.start();
        controller.nexus.startListening();
    }

    public void getReportsFromNodes(Collator controller) throws InterruptedException {
        Thread.sleep(2000);
        while(controller.nexus.getSummation().size() != controller.numberOfNodes){
            System.out.println("Number of nodes reporting back: " + controller.nexus.getSummation().size() + ". Please wait...");
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Number of nodes reporting back: " + controller.nexus.getSummation().size() + ". Please wait...");
        Vector<Integer> summations = controller.nexus.getSummation();
        Vector<Integer> sendTrackers = controller.nexus.getSendTrackerFromAutoNode();
        Vector<Integer> receiveTrackers = controller.nexus.getReceiveTrackerFromAutoNode();
        Vector<Integer> sendSummation = controller.nexus.getSendSummation();
        printData(summations, sendTrackers, receiveTrackers, sendSummation);
    }

    public void printData(Vector<Integer> summations, Vector<Integer> sendTrackers, Vector<Integer> receiveTrackers, Vector<Integer> sendSummation){
        int summationSum = 0;
        int sendSum = 0;
        int receiveSum = 0;
        int senderSummation = 0;
        System.out.println("\n_____________________________________________________________________________________________________________________");
        System.out.printf("| %20s  | %20s | %20s | %20s | %20s |", "Node Number", "Receiver Sum", "Messages sent", "Messages received", "Sender Sum");
        System.out.printf("\n|___________________________________________________________________________________________________________________|");
        for(int i = 0; i < summations.size(); i++){
            System.out.printf ("\n| %20s%d | %20d | %20d | %20d | %20d |", "Node", i+1, summations.get(i), sendTrackers.get(i), receiveTrackers.get(i), sendSummation.get(i));
            summationSum +=summations.get(i);
            sendSum += sendTrackers.get(i);
            receiveSum += receiveTrackers.get(i);
            senderSummation += sendSummation.get(i);
        }
        System.out.printf("\n|___________________________________________________________________________________________________________________|");
        System.out.printf("\n|                                 ---------------------------TOTALS-------------------------------                  |");
        System.out.printf("\n|%20s | %20s | %20s | %20s", "Summation received", "messages sent", "messages received", "summation sent");
        System.out.printf("\n|___________________________________________________________________________________________________________________|");
        System.out.printf ("\n|%20d | %20d | %20d | %20d |", summationSum, sendSum, receiveSum, senderSummation);
        System.out.printf("\n|___________________________________________________________________________________________________________________|\n\nSystem Exiting...\n\n");
        System.exit(0);
    }

    public void run(){
        try {
            getReportsFromNodes(this);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}