import java.io.*;
import java.lang.*;
import java.net.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class Node extends Thread implements Runnable, Serializable {
    //generic variables
    private InetAddress ip;
    private int numMessagesReceived;
    private Vector<String> receivedMessages = new Vector<String>();
    private Vector<ClientHandler> allClients = new Vector<>();
    private boolean AutoNode;

    //collator variables
    private Vector<Integer> receiveTrackerFromAutoNode = new Vector<>();
    private Vector<Integer> sendTrackerFromAutoNode =  new Vector<>();
    private Vector<Integer> summation = new Vector<>();
    private Vector<Integer> sendSummation = new Vector<>();


    //client variables
    private DataOutputStream clientOut;
    private int connectPort;
    private Socket socket;

    //server variables
    //private Scanner serverIn;
    private Integer listeningPort;
    private ServerSocket listener;
    private int partialSum = 0;

    //class variables
    private static Vector<Integer> takenPorts = new Vector<Integer>();

    //constructor
    Node() {
        this.listeningPort = this.generatePort();
        try {
            this.ip = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    //getters
    public InetAddress getip() {
        return (this.ip);
    }

    public int getListeningPort() {
        return (this.listeningPort);
    }

    public int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }

    public int getConnectPort() {
        return (this.connectPort);
    }

    public DataOutputStream getClientOut() { return this.clientOut; }

    public synchronized int getNumMessagesReceived() { return this.numMessagesReceived;}

    public Vector<Integer> getReceiveTrackerFromAutoNode() { return this.receiveTrackerFromAutoNode;}

    public Vector<Integer> getSendTrackerFromAutoNode() { return this.sendTrackerFromAutoNode;}

    public Vector<Integer> getSummation() { return this.summation;}

    public synchronized int getPartialSum(){ return this.partialSum; }

    public Vector<Integer> getSendSummation() {return this.sendSummation;}


    //setters
    public void setConnectPort(int connectPort) {
        this.connectPort = connectPort;
    }

    public void setClientOut(DataOutputStream printer) {
        this.clientOut = printer;
    }

    public void setAutoNode(boolean value){this.AutoNode = value; }

    //CLIENT FUNCTIONS
    //this method sets the socket from the client view to try and
    //establish a connection with another server/node
    public boolean attemptConnection(InetAddress hostIp) {
        try {
            try {
                this.socket = new Socket(hostIp, this.getConnectPort());
            } catch (java.net.ConnectException e){
                System.out.println("trying new socket");
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            this.setClientOut(new DataOutputStream(socket.getOutputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    public void sendMessageToServer(int message) {
        try {
            this.getClientOut().writeInt(message);
            this.getClientOut().flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //SERVER FUNCTIONS
    //create listening socket to act as server
    public void setServerSocket() {
        try {
            this.listener = new ServerSocket(this.getListeningPort());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //This method is the server view of the socket to another node
    public void startListening() {
        try {
            while (true) {
                Socket client = this.listener.accept();
                //System.out.println("New client connected " + client.getInetAddress().getHostAddress());
                // create a new thread object
                ClientHandler clientSock = new ClientHandler(client, this, this.AutoNode);
                this.allClients.add(clientSock);
                // This thread will handle the client
                // separately
                new Thread(clientSock).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (this.listener != null) {
                try {
                    //System.out.println("Connection closed getting messages");
                    this.listener.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //assigns a random port number to this node to listen and accept connection on.
    public int generatePort() {
        int port = (50000 + getRandomNumber(1, 999));
        while (Node.takenPorts.contains(port)) {
            port = (50000 + getRandomNumber(1, 999));
        }
        Node.takenPorts.add(port);
        return port;
    }

    //clears the data structure storing all Node port numbers
    //use with caution
    public static void clearPorts() {
        Node.takenPorts.clear();
    }

    public synchronized void updatePartialSum(int number){
        this.partialSum += number;
    }

    public synchronized void updateReceiverInfo(int numMessagesReceived){
        this.numMessagesReceived += numMessagesReceived;
    }

    public void setInfoForCollator(int receiveTracker, int sendTracker, int summation, int sendSummation){
        this.receiveTrackerFromAutoNode.add(receiveTracker);
        this.sendTrackerFromAutoNode.add(sendTracker);
        this.summation.add(summation);
        this.sendSummation.add(sendSummation);
    }

    public void run(){
        this.startListening();
    }
}