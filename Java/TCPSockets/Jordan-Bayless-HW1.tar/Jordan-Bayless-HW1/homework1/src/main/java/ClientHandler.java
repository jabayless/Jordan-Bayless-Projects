import java.io.*;
import java.net.*;
import java.util.ArrayList;

// ClientHandler class
public class ClientHandler implements Runnable {
    Node parentNode;

    boolean isAutoNode;

    private final Socket clientSocket;

    private ArrayList<Integer> messages = new ArrayList<>();

    private int numMessagesReceived = 0;

    private int getNumMessagesReceived() { return  numMessagesReceived;}

    private ArrayList<Integer> getMessages(){ return this.messages;}

    private int autoNodeReceiveTracker = 0;

    private int autoNodeSendTracker = 0;

    private int summation = 0;

    private int sendSummation = 0;

    // Constructor
    public ClientHandler(Socket socket, Node parentNode, boolean isAutoNode) {
        this.clientSocket = socket;
        this.parentNode = parentNode;
        this.isAutoNode = isAutoNode;
    }

    public void run() {
        boolean sent = false;
        PrintWriter out = null;
        DataInputStream in = null;
        try {
            // get the outputstream of client
            // get the inputstream of client
            in = new DataInputStream(clientSocket.getInputStream());
            try {
                if((this.isAutoNode)) {
                    for (int i = 0; i < 5; i++) {
                        int incomingInt = in.readInt();
                        // writing the received message from
                        //receiving end of nodes as servers

                        this.parentNode.updateReceiverInfo(1);
                        this.parentNode.updatePartialSum(incomingInt);
                    }
                }
                    //on event send the messages to the collator
                    //receiving end of collator
                    else if(!this.isAutoNode){
                        this.autoNodeReceiveTracker = in.readInt();
                        this.autoNodeSendTracker = in.readInt();
                        this.summation = in.readInt();
                        this.sendSummation = in.readInt();
                        this.parentNode.setInfoForCollator(this.autoNodeReceiveTracker,
                                this.autoNodeSendTracker, this.summation, this.sendSummation);
                    }
                } catch (java.net.SocketException e){
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if(!sent)
                this.parentNode.updateReceiverInfo(this.messages.size());
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                    clientSocket.close();
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}