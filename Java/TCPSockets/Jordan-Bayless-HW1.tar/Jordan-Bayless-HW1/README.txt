Jordan A Bayless
CS455
HW1 Experimenting with Network Communications
2-16-2020

This is the Readme for homework1 CS455.

Classes:
AutoNode
Collator
Node
ClientHandler

Resources
build.gradle
Addresses.txt

Description of classes:

-Collator: once deployed to a computer and run, collator will prompt the user to enter
an integer between 5 and 9 representing the number of nodes that will be online in the system.
The collator will then wait for the number of nodes entered to post their IP and Port numbers
to the Addresses.txt file, once this happens, Collator will post its own IP and Port number to
the Addresses.txt file which the nodes will use as a signal to begin their communications.
Once collator posts its Ip and port to the file, it starts up a node class and activates
its listening socket and waits for the messaging nodes to send their reports of number of
messages sent, number of messages received, and integer summations. Once all nodes have
reported back, collator will display this information into a table.

-Node: this represents both a client and server node. It can listen for and receive communications
as well as spawn sockets for listening and sending information. It is a peer 2 peer network in which
all nodes are capable of simultaneously sending and receiving information. One thread listens for new
connections while another will send information. If a new connection comes in to Node's serversocket,
it will generate a new regular socket and pass it to a ClientHandler object that will handle receiving
communications on the newly created socket.

-ClientHandler: This class represents a single receiving socket for the node or the collator. As
many ClientHandlers are active as there are active sockets on each node. Once the clienthandler is
created, it receives integer messages through its socket and terminates once no new messages are being
received. It also passes its information back to the node before destroying itself and the thread it
operates on.

-AutoNode: This class will run and call the methods of the Node class and setup and tear down Node object.
The node object will be used to send 5000 rounds of 5 integers to random other Nodes on the network. It
receives the IP and Port numbers about other nodes on the network via "Addresses.txt" on the share drive.
Once it has completed its 5000 rounds, it will report its information back to the Collator.

How to Run Program:
1.) Deploy the directory containing the gradle build files and java objects to all computers
via SCP or other means of copying files.
2.) Open n+1 terminals where n is the number of nodes you will be running (between 5 and 9).
    a.)This terminal will begin waiting for the nodes to come online.
3.) run following command on the first terminal only:clear & java Collator
    a.) You will be prompted to enter the number of nodes you will activate on the network
4.) on all the other terminals, run the following command:clear & java AutoNode
5.)Once all the nodes are active + the collator, the messages will begin sending their communications
6.)Go to the terminal with the collator, which after ~30s will present a table showing the results
of the network communications and then it will terminate.

